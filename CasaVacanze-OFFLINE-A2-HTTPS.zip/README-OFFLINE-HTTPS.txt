CASA VACANZE - OFFLINE su iPhone/iPad (A2)

IMPORTANTE:
Su iPhone/iPad l'offline funziona SOLO se installi l'app da un indirizzo HTTPS.
Dopo: Safari -> Condividi -> Aggiungi alla schermata Home. Poi funziona anche senza internet.

Metodo più semplice (gratis): Netlify (drag & drop)
- Carica questa cartella (o lo zip) su Netlify con deploy manuale
- Ti dà un link https://....
- Apri quel link su iPhone -> Aggiungi alla Home

Dati:
Restano nel dispositivo. Per usarli su più dispositivi: Esporta/Importa e salva il backup su Google Drive.
